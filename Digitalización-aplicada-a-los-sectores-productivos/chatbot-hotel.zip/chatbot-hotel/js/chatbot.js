// CONFIGURACIÓN Y VARIABLES GLOBALES

// Generar ID de sesión
const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);

// URL Google Apps Script
const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbzR7AkXJGqqphfM143V-rqKQ4O9ya4qfB1wKeqsAN9fKL1pT0U5nOVCxzIAkHKw0WjxDw/exec';

// controlar si está procesando
let isProcessing = false;

// FUNCIONES DE INTERFAZ DE USUARIO

/**
 * Añade un mensaje al área de chat 
 * @param {string} sender 
 * @param {string} text 
 */

function addMessage(sender, text) {
    const messagesDiv = document.getElementById('chatMessages');
    const typingIndicator = messagesDiv.querySelector('.typing-indicator');
    
    // Crear contenedor del mensaje
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ' + sender;
    
    // Crear avatar
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = sender === 'bot' ? '🤖' : '👤';
    
    // Crear contenido
    const content = document.createElement('div');
    content.className = 'message-content';
    content.textContent = text;
    
    // Ensamblar mensaje
    messageDiv.appendChild(avatar);
    if (sender === 'user') {
        messageDiv.appendChild(content);
    } else {
        messageDiv.insertBefore(content, avatar.nextSibling);
    }
    
    // Insertar antes del indicador de escritura
    messagesDiv.insertBefore(messageDiv, typingIndicator.parentElement);
    
    // Scroll al final
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

/**
 * Muestra u oculta el indicador de escritura
 * @param {boolean} show - true para mostrar
 */
function showTyping(show) {
    const typingIndicator = document.querySelector('.typing-indicator');
    if (show) {
        typingIndicator.classList.add('active');
    } else {
        typingIndicator.classList.remove('active');
    }
    document.getElementById('chatMessages').scrollTop = document.getElementById('chatMessages').scrollHeight;
}

/**
 * Deshabilita o habilita los controles de la interfaz
 * @param {boolean} disabled - true para deshabilitar
 */
function setControlsDisabled(disabled) {
    const input = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    const quickBtns = document.querySelectorAll('.quick-btn');
    
    input.disabled = disabled;
    sendBtn.disabled = disabled;
    quickBtns.forEach(btn => btn.disabled = disabled);
    
    if (!disabled) {
        input.focus();
    }
}

// FUNCIONES DE INTEGRACIÓN

/**
 * Guarda la conversación en Google Sheets
 * @param {string} userMessage - Mensaje del usuario
 * @param {string} botResponse - Respuesta del bot
 */
async function saveToGoogleSheets(userMessage, botResponse) {
    try {
        await fetch(GOOGLE_SCRIPT_URL, {
            method: 'POST',
            mode: 'no-cors',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                sessionId: sessionId,
                timestamp: new Date().toISOString(),
                userMessage: userMessage,
                botResponse: botResponse
            })
        });
        console.log('Conversación guardada en Google Sheets');
    } catch (error) {
        console.error('Error al guardar en Google Sheets:', error);
    }
}

/**
 * Devuelve un mensaje por defecto cuando no se reconoce la intención
 * @returns {string} - Mensaje de error con opciones
 */
function getDefaultResponse() {
    return '❌ Perdona no he entendido tu pregunta.\n\n¿qué te gustaría saber?\n• Preguntar por servicios del hotel\n• Ver horarios (check-in/check-out)\n• Información sobre habitaciones\n• Recomendaciones locales\n• Hablar con recepción';
}

// LÓGICA DEL CHATBOT ANÁLISIS DE INTENCIÓN

/**
 * Analiza intención y devuelve respuesta apropiada
 * @param {string} message - Mensaje del usuario
 * @returns {Promise<string>} - Respuesta del bot
 */
async function analyzeIntent(message) {
    const lowerMessage = message.toLowerCase();
    
    // Intención: Hablar con recepción / Personal humano
    if (lowerMessage.includes('recepción') || lowerMessage.includes('recepcion') || 
        lowerMessage.includes('persona') || lowerMessage.includes('humano') ||
        lowerMessage.includes('hablar con alguien') || lowerMessage.includes('ayuda urgente') ||
        lowerMessage.includes('contactar') || lowerMessage.includes('llamar') ||
        lowerMessage.includes('telefono') || lowerMessage.includes('teléfono') ||
        lowerMessage.includes('ayuda personal') || lowerMessage.includes('hablar con') ||
        lowerMessage.includes('necesito hablar') || lowerMessage.includes('atencion personal') ||
        lowerMessage.includes('atención personal')) {
        return '📞 Por supuesto, te pongo en contacto con nuestro personal.\n\n🏨 **Opciones de contacto:**\n• **Teléfono:** +34 965 123 456\n• **Email:** recepcion@hotelcostaazul.com\n• **WhatsApp:** +34 123 456 789\n\nUn recepcionista te atenderá de inmediato. Si prefieres, puedes esperar y un miembro de nuestro equipo te contactará por este chat en unos minutos.\n\n¿Hay algo más en lo que pueda ayudarte mientras tanto?';
    }

    // Intención: Check-in/Check-out y Horarios
    if (lowerMessage.includes('check') || lowerMessage.includes('entrada') || 
        lowerMessage.includes('salida') || lowerMessage.includes('horario') ||
        lowerMessage.includes('hora') || lowerMessage.includes('cuando') ||
        lowerMessage.includes('llegada') || lowerMessage.includes('entrar') ||
        lowerMessage.includes('salir') || lowerMessage.includes('checkout') ||
        lowerMessage.includes('checkin') || lowerMessage.includes('llegar')) {
        return '🕐 **Horarios del Hotel:**\n\n• **Check-in:** A partir de las 15:00h\n• **Check-out:** Hasta las 12:00h\n\n📋 **Información adicional:**\n• Check-in anticipado: Sujeto a disponibilidad (consultar con recepción)\n• Check-out tardío: Posible con suplemento según disponibilidad\n• Recepción 24 horas: Siempre disponible para atenderte\n\n¿Necesitas información sobre algún otro servicio?';
    }

    // Intención: Parking / Aparcamiento
    if (lowerMessage.includes('parking') || lowerMessage.includes('aparcamiento') || 
        lowerMessage.includes('aparcar') || lowerMessage.includes('coche') ||
        lowerMessage.includes('estacionamiento') || lowerMessage.includes('garaje') ||
        lowerMessage.includes('vehiculo') || lowerMessage.includes('vehículo') ||
        lowerMessage.includes('plaza') || lowerMessage.includes('donde aparco') ||
        lowerMessage.includes('dónde aparco')) {
        return '🚗 **Parking del Hotel:**\n\n• **Parking privado:** SÍ disponible\n• **Coste:** 12€/día\n• **Ubicación:** En el edificio del hotel (subterráneo)\n• **Disponibilidad:** Sujeto a disponibilidad\n• **Recomendación:** Reservar con antelación\n\n🅿️ **Alternativa gratuita:**\nParking público gratuito a 5 minutos caminando del hotel.\n\n¿Deseas reservar una plaza de parking?';
    }

    // Intención: WiFi / Internet
    if (lowerMessage.includes('wifi') || lowerMessage.includes('wi-fi') || 
        lowerMessage.includes('internet') || lowerMessage.includes('conexión') ||
        lowerMessage.includes('conexion') || lowerMessage.includes('red') ||
        lowerMessage.includes('contraseña') || lowerMessage.includes('password') ||
        lowerMessage.includes('conectar') || lowerMessage.includes('datos')) {
        return '📶 **WiFi Gratuito:**\n\n✅ ¡Disponible en TODO el hotel sin coste adicional!\n\n📡 **Detalles de conexión:**\n• **Nombre de red:** HotelCostaAzul_Guest\n• **Contraseña:** Te la proporcionaremos en recepción al hacer check-in\n• **Cobertura:** Habitaciones, zonas comunes, piscina y restaurante\n• **Velocidad:** Alta velocidad (fibra óptica)\n\n¿Necesitas ayuda con alguna otra información?';
    }

    // Intención: Desayuno / Restaurante / Comida
    if (lowerMessage.includes('desayuno') || lowerMessage.includes('comida') || 
        lowerMessage.includes('restaurante') || lowerMessage.includes('cena') ||
        lowerMessage.includes('comer') || lowerMessage.includes('cenar') ||
        lowerMessage.includes('menu') || lowerMessage.includes('menú') ||
        lowerMessage.includes('bar') || lowerMessage.includes('cocina') ||
        lowerMessage.includes('almuerzo') || lowerMessage.includes('bebida') ||
        lowerMessage.includes('gastronomia') || lowerMessage.includes('gastronomía')) {
        return '🍽️ **Restaurante y Desayuno del Hotel:**\n\n🥐 **Desayuno buffet:**\n• Horario: 7:30h - 10:30h\n• Precio: 15€/persona\n• Variedad: Continental, zumos naturales, repostería casera\n\n🍴 **Restaurante:**\n• **Almuerzo:** 13:00h - 16:00h\n• **Cena:** 19:30h - 23:00h\n• **Cocina:** Mediterránea con productos locales frescos\n• **Especialidad:** Pescados y arroces\n\n🍹 **Bar terraza:**\n• Horario: 10:00h - 00:00h\n• Aperitivos, cócteles y tapas\n\n💡 **Recomendación:** Reserva mesa en recepción para garantizar disponibilidad.\n\n¿Te gustaría saber sobre otros servicios?';
    }

    // Intención: Mascotas / Animales
    if (lowerMessage.includes('mascota') || lowerMessage.includes('perro') || 
        lowerMessage.includes('gato') || lowerMessage.includes('animal') ||
        lowerMessage.includes('pet') || lowerMessage.includes('cachorro') ||
        lowerMessage.includes('peludos') || lowerMessage.includes('puedo traer')) {
        return '🐾 **Política de Mascotas:**\n\n✅ ¡SÍ! Aceptamos mascotas en nuestro hotel.\n\n📋 **Condiciones:**\n• **Suplemento:** 20€/noche por mascota\n• **Peso máximo:** Hasta 15kg\n• **Habitaciones:** Específicas para mascotas (limitadas)\n• **Requisitos:** Cartilla veterinaria al día\n\n⚠️ **Importante:**\n• Informar en la reserva\n• Las mascotas deben ir con correa en zonas comunes\n• No están permitidas en restaurante y piscina\n\n🏖️ **Bonus:** Playa cercana que admite perros a 10 minutos.\n\n¿Necesitas más información?';
    }

    // Intención: Servicios generales / Instalaciones
    if (lowerMessage.includes('servicio') || lowerMessage.includes('piscina') || 
        lowerMessage.includes('spa') || lowerMessage.includes('gimnasio') ||
        lowerMessage.includes('instalaciones') || lowerMessage.includes('instalacion') ||
        lowerMessage.includes('facilidades') || lowerMessage.includes('que ofrece') ||
        lowerMessage.includes('qué ofrece') || lowerMessage.includes('que tiene') ||
        lowerMessage.includes('qué tiene') || lowerMessage.includes('amenidades') ||
        lowerMessage.includes('que hay') || lowerMessage.includes('qué hay')) {
        return '🏊 **Servicios del Hotel Costa Azul:**\n\n💦 **Piscina exterior:**\n• Horario: 8:00h - 21:00h\n• Climatizada durante todo el año\n• Zona de hamacas y sombrillas\n• Servicio de toallas gratuito\n\n💆 **Spa & Wellness:**\n• Horario: 9:00h - 20:00h\n• Masajes, tratamientos faciales y corporales\n• Sauna y jacuzzi\n• Reserva previa en recepción\n\n💪 **Gimnasio:**\n• Acceso 24 horas\n• Equipamiento moderno\n• Acceso con tarjeta de habitación\n\n🌅 **Otros servicios:**\n• Solarium y zona chill-out\n• Recepción 24h\n• Servicio de conserjería\n• Sala de reuniones\n• Parking privado\n\n¿Te gustaría información específica sobre algún servicio?';
    }

    // Intención: Habitaciones / Reservas / Disponibilidad
    if (lowerMessage.includes('habitación') || lowerMessage.includes('habitacion') || 
        lowerMessage.includes('room') || lowerMessage.includes('suite') ||
        lowerMessage.includes('reserva') || lowerMessage.includes('disponibilidad') ||
        lowerMessage.includes('precio') || lowerMessage.includes('cuanto cuesta') ||
        lowerMessage.includes('cuánto cuesta') || lowerMessage.includes('tarifa') ||
        lowerMessage.includes('coste') || lowerMessage.includes('alojamiento') ||
        lowerMessage.includes('dormir') || lowerMessage.includes('cama') ||
        lowerMessage.includes('tipos de habitacion') || lowerMessage.includes('reservar') ||
        lowerMessage.includes('capacidad') || lowerMessage.includes('personas') ||
        lowerMessage.includes('cancelar') || lowerMessage.includes('cancelación') ||
        lowerMessage.includes('cancelacion') || lowerMessage.includes('devolucion') ||
        lowerMessage.includes('devolución')) {
        return '🛏️ **Tipos de Habitaciones - Hotel Costa Azul:**\n\n**1. Habitación Estándar** 👥 2 personas\n   • Desde 89€/noche\n   • Cama doble o dos individuales\n   • Baño privado, TV, aire acondicionado, minibar\n   • Desayuno: NO incluido (+15€/persona)\n\n**2. Habitación Superior** 👥 2-3 personas\n   • Desde 129€/noche\n   • Vista al mar, balcón privado\n   • Todas las comodidades + cafetera\n   • Desayuno: SÍ incluido\n\n**3. Suite Familiar** 👥 4 personas\n   • Desde 189€/noche\n   • Salón independiente, 2 baños\n   • Terraza con vistas panorámicas\n   • Desayuno: SÍ incluido\n\n📋 **Política de Cancelación:**\n• ✅ Cancelación GRATUITA hasta 48 horas antes de la llegada\n• ❌ Cancelaciones tardías: cargo del 50% de la primera noche\n• ❌ No-show: cargo del 100% de la primera noche\n\n💳 **Para reservar:**\n• Web: www.hotelcostaazul.com\n• Teléfono: +34 123 456 789\n• Email: reservas@hotelcostaazul.com\n\n¿Necesitas ayuda para elegir la habitación ideal?';
    }

    // Intención: Recomendaciones locales / Turismo / Actividades
    if (lowerMessage.includes('recomendación') || lowerMessage.includes('recomendacion') || 
        lowerMessage.includes('que hacer') || lowerMessage.includes('qué hacer') ||
        lowerMessage.includes('hacer cerca') || lowerMessage.includes('visitar') ||
        lowerMessage.includes('turismo') || lowerMessage.includes('actividades') ||
        lowerMessage.includes('tarde') || lowerMessage.includes('plan') ||
        lowerMessage.includes('cerca del hotel') || lowerMessage.includes('alrededores') ||
        lowerMessage.includes('lugares') || lowerMessage.includes('sitios') ||
        lowerMessage.includes('que ver') || lowerMessage.includes('qué ver') ||
        lowerMessage.includes('excursion') || lowerMessage.includes('excursión') ||
        lowerMessage.includes('playa') || lowerMessage.includes('pueblo') ||
        lowerMessage.includes('ciudad') || lowerMessage.includes('cenar fuera') ||
        lowerMessage.includes('donde comer') || lowerMessage.includes('dónde comer') ||
        lowerMessage.includes('restaurantes cerca') || lowerMessage.includes('ocio') ||
        lowerMessage.includes('entretenimiento') || lowerMessage.includes('por la zona')) {
        return '🌴 **Recomendaciones Locales - Descubre la Costa Azul:**\n\n🏛️ **Lugares Turísticos:**\n• **Casco Antiguo** (10 min) - Calles empedradas, arquitectura medieval, iglesia del s.XVI\n• **Mirador del Faro** (15 min) - Vistas espectaculares al atardecer, perfecto para fotos\n• **Playa de las Rocas** (5 min caminando) - Aguas cristalinas, ideal para snorkel\n\n🍽️ **Restaurantes Recomendados:**\n• **La Marisquería del Puerto** - Pescado fresco del día y paellas espectaculares (€€€)\n• **El Rincón Mediterráneo** - Cocina tradicional, ambiente familiar (€€)\n• **Taberna del Mar** - Tapas auténticas y vinos locales, muy popular (€)\n\n🎯 **Actividades:**\n• **Excursiones en barco:** Salidas diarias 10:00h - Avistamiento de delfines\n• **Ruta de senderismo costera:** 3h aproximadamente - Dificultad media\n• **Mercadillo local:** Sábados 9:00h-14:00h - Productos artesanales\n• **Kayak y paddle surf:** Alquiler en la playa principal\n• **Clases de buceo:** Centro certificado a 500m del hotel\n\n🌙 **Por la tarde/noche:**\n• Paseo marítimo con terrazas y heladerías\n• Cine de verano (julio-agosto)\n• Conciertos en la plaza del pueblo (fines de semana)\n\n💡 **Consejo:** Pide en recepción el mapa turístico con descuentos exclusivos para huéspedes.\n\n¿Te gustaría información más específica sobre alguna actividad?';
    }

    // Intención: Saludos
    if (lowerMessage.includes('hola') || lowerMessage.includes('buenos') || 
        lowerMessage.includes('buenas') || lowerMessage.includes('hey') ||
        lowerMessage.includes('saludos') || lowerMessage.includes('que tal') ||
        lowerMessage.includes('qué tal')) {
        return '¡Hola! 👋 Bienvenido/a al Hotel Costa Azul.\n\nSoy tu asistente virtual y estoy aquí para ayudarte con cualquier consulta sobre:\n\n• Servicios del hotel\n• Información sobre habitaciones\n• Horarios y servicios\n• Recomendaciones de la zona\n• Contacto con recepción\n\n¿En qué puedo ayudarte hoy?';
    }

    // Si no reconoce la intención
    return getDefaultResponse();
}

// FUNCIONES DE MANEJO DE EVENTOS

/** Envía el mensaje del usuario y obtiene la respuesta del bot */
async function sendMessage() {
    if (isProcessing) return;

    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;

    // Deshabilitar controles y marcar como procesando
    isProcessing = true;
    setControlsDisabled(true);

    // Añadir mensaje del usuario
    addMessage('user', message);
    input.value = '';

    // Mostrar indicador de escritura
    showTyping(true);

    // Procesar respuesta
    try {
        const response = await analyzeIntent(message);
        
        setTimeout(() => {
            showTyping(false);
            addMessage('bot', response);
            saveToGoogleSheets(message, response);
            
            // Habilitar controles
            isProcessing = false;
            setControlsDisabled(false);
        }, 1000);
    } catch (error) {
        console.error('Error al procesar mensaje:', error);
        showTyping(false);
        addMessage('bot', '❌ Lo siento, ha ocurrido un error. Por favor, intenta de nuevo o contacta con recepción al +34 123 456 789.');
        isProcessing = false;
        setControlsDisabled(false);
    }
}

/**
 * Maneja los clicks en los botones de acción rápida
 * @param {string} action  tipo de accion*/
async function handleQuickAction(action) {
    if (isProcessing) return;

    let message = '';
    switch(action) {
        case 'servicios':
            message = 'Quiero saber sobre los servicios del hotel';
            break;
        case 'habitaciones':
            message = 'Información sobre habitaciones';
            break;
        case 'recomendaciones':
            message = '¿Qué puedo hacer cerca del hotel?';
            break;
        case 'recepcion':
            message = 'Quiero hablar con recepción';
            break;
    }

    document.getElementById('chatInput').value = message;
    sendMessage();
}

/**
 * Maneja el evento de presionar tecla en el input
 * @param {Event} event - Evento del teclado
 */
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage();
    }
}

// INICIALIZACIÓN

/**
 * Inicializa el chatbot cuando se carga la página
 */
document.addEventListener('DOMContentLoaded', function() {
    // Ocultar el indicador de escritura al inicio
    showTyping(false);
    
    // Enfocar el input
    document.getElementById('chatInput').focus();
    
    console.log('✅ Chatbot del Hotel Costa Azul inicializado');
    console.log('📋 Session ID:', sessionId);
});