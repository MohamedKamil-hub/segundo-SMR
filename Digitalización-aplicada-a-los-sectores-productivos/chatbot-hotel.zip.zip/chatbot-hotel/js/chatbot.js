
// CONFIGURACIÓN Y VARIABLES GLOBALES


// Generar ID único de sesión
const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);

// URL del script de Google Apps Script
const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbzR7AkXJGqqphfM143V-rqKQ4O9ya4qfB1wKeqsAN9fKL1pT0U5nOVCxzIAkHKw0WjxDw/exec';

// Variable para controlar si está procesando
let isProcessing = false;


// FUNCIONES DE INTERFAZ DE USUARIO


/**
 * Añade un mensaje al área de chat
 * @param {string} sender 
 * @param {string} text 
 */
function addMessage(sender, text) {
    const messagesDiv = document.getElementById('chatMessages');
    const typingIndicator = messagesDiv.querySelector('.typing-indicator');
    
    // Crear contenedor del mensaje
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ' + sender;
    
    // Crear avatar
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = sender === 'bot' ? '🤖' : '👤';
    
    // Crear contenido
    const content = document.createElement('div');
    content.className = 'message-content';
    content.textContent = text;
    
    // Ensamblar mensaje
    messageDiv.appendChild(avatar);
    if (sender === 'user') {
        messageDiv.appendChild(content);
    } else {
        messageDiv.insertBefore(content, avatar.nextSibling);
    }
    
    // Insertar antes del indicador de escritura
    messagesDiv.insertBefore(messageDiv, typingIndicator.parentElement);
    
    // Scroll al final
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

/**
 * Muestra u oculta el indicador de escritura
 * @param {boolean} show - true para mostrar, false para ocultar
 */
function showTyping(show) {
    const typingIndicator = document.querySelector('.typing-indicator');
    if (show) {
        typingIndicator.classList.add('active');
    } else {
        typingIndicator.classList.remove('active');
    }
    document.getElementById('chatMessages').scrollTop = document.getElementById('chatMessages').scrollHeight;
}

/**
 * Deshabilita o habilita los controles de la interfaz
 * @param {boolean} disabled - true para deshabilitar, false para habilitar
 */
function setControlsDisabled(disabled) {
    const input = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    const quickBtns = document.querySelectorAll('.quick-btn');
    
    input.disabled = disabled;
    sendBtn.disabled = disabled;
    quickBtns.forEach(btn => btn.disabled = disabled);
    
    if (!disabled) {
        input.focus();
    }
}

// ========================================
// FUNCIONES DE INTEGRACIÓN
// ========================================

/**
 * Guarda la conversación en Google Sheets
 * @param {string} userMessage - Mensaje del usuario
 * @param {string} botResponse - Respuesta del bot
 */
async function saveToGoogleSheets(userMessage, botResponse) {
    try {
        await fetch(GOOGLE_SCRIPT_URL, {
            method: 'POST',
            mode: 'no-cors',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                sessionId: sessionId,
                timestamp: new Date().toISOString(),
                userMessage: userMessage,
                botResponse: botResponse
            })
        });
        console.log('Conversación guardada en Google Sheets');
    } catch (error) {
        console.error('Error al guardar en Google Sheets:', error);
    }
}

/**
 * Devuelve un mensaje por defecto cuando no se reconoce la intención
 * @returns {string} - Mensaje de error con opciones
 */
function getDefaultResponse() {
    return '❌ Lo siento, no he entendido tu pregunta.\n\n¿Sobre qué te gustaría saber?\n• Servicios del hotel\n• Habitaciones y precios\n• Recomendaciones locales\n• Hablar con recepción';
}

// ========================================
// LÓGICA DEL CHATBOT (ANÁLISIS DE INTENCIÓN)
// ========================================

/**
 * Analiza la intención del usuario y devuelve la respuesta apropiada
 * @param {string} message - Mensaje del usuario
 * @returns {Promise<string>} - Respuesta del bot
 */
async function analyzeIntent(message) {
    const lowerMessage = message.toLowerCase();
    
    // Intención: Hablar con recepción
    if (lowerMessage.includes('recepción') || lowerMessage.includes('recepcion') || 
        lowerMessage.includes('persona') || lowerMessage.includes('humano') ||
        lowerMessage.includes('hablar con alguien') || lowerMessage.includes('ayuda urgente')) {
        return '📞 Por supuesto, te pongo en contacto con nuestro personal.\n\n🏨 **Opciones de contacto:**\n• Teléfono: +34 965 123 456\n• Email: recepcion@hotelcostaazul.com\n• WhatsApp: +34 600 123 456\n\nUn miembro de nuestro equipo te atenderá de inmediato. ¿Hay algo más en lo que pueda ayudarte mientras tanto?';
    }

    // Intención: Check-in/Check-out
    if (lowerMessage.includes('check') || lowerMessage.includes('entrada') || 
        lowerMessage.includes('salida') || lowerMessage.includes('horario')) {
        return '🕐 **Horarios del Hotel:**\n\n• **Check-in:** A partir de las 15:00h\n• **Check-out:** Hasta las 12:00h\n\nSi necesitas check-in anticipado o check-out tardío, consulta con recepción según disponibilidad.';
    }

    // Intención: Parking
    if (lowerMessage.includes('parking') || lowerMessage.includes('aparcamiento') || 
        lowerMessage.includes('aparcar') || lowerMessage.includes('coche')) {
        return '🚗 **Parking:**\n\nDisponemos de parking privado para nuestros huéspedes.\n• **Coste:** 12€/día\n• **Ubicación:** En el edificio del hotel\n• **Disponibilidad:** Sujeto a disponibilidad (se recomienda reservar)\n\nTambién hay parking público gratuito a 5 minutos caminando.';
    }

    // Intención: WiFi
    if (lowerMessage.includes('wifi') || lowerMessage.includes('wi-fi') || 
        lowerMessage.includes('internet') || lowerMessage.includes('conexión')) {
        return '📶 **WiFi Gratuito:**\n\n¡Disponible en todo el hotel sin coste adicional!\n• Red: HotelCostaAzul_Guest\n• Contraseña: Te la proporcionaremos en recepción\n• Cobertura: Habitaciones, zonas comunes y piscina';
    }

    // Intención: Desayuno/Restaurante
    if (lowerMessage.includes('desayuno') || lowerMessage.includes('comida') || 
        lowerMessage.includes('restaurante') || lowerMessage.includes('cena') ||
        lowerMessage.includes('comer')) {
        return '🍽️ **Restaurante y Desayuno:**\n\n• **Desayuno buffet:** 7:30h - 10:30h (15€/persona)\n• **Restaurante almuerzo:** 13:00h - 16:00h\n• **Restaurante cena:** 19:30h - 23:00h\n• **Bar terraza:** 10:00h - 00:00h\n\nCocina mediterránea con productos locales. ¡Reserva mesa en recepción!';
    }

    // Intención: Mascotas
    if (lowerMessage.includes('mascota') || lowerMessage.includes('perro') || 
        lowerMessage.includes('gato') || lowerMessage.includes('animal')) {
        return '🐾 **Política de Mascotas:**\n\n¡Sí! Aceptamos mascotas en nuestro hotel.\n• **Suplemento:** 20€/noche por mascota\n• **Peso máximo:** Hasta 15kg\n• **Habitaciones:** Específicas para mascotas\n\nPor favor, infórmanos en la reserva para preparar todo.';
    }

    // Intención: Servicios generales
    if (lowerMessage.includes('servicio') || lowerMessage.includes('piscina') || 
        lowerMessage.includes('spa') || lowerMessage.includes('gimnasio') ||
        lowerMessage.includes('instalaciones')) {
        return '🏊 **Servicios del Hotel:**\n\n• **Piscina exterior:** 8:00h - 21:00h (climatizada)\n• **Spa & Wellness:** 9:00h - 20:00h (reserva previa)\n• **Gimnasio:** 24h (acceso con tarjeta)\n• **Solarium:** Zona de hamacas y sombrillas\n• **Servicio de toallas:** Disponible en piscina\n• **Recepción 24h:** Siempre a tu disposición';
    }

    // Intención: Habitaciones
    if (lowerMessage.includes('habitación') || lowerMessage.includes('habitacion') || 
        lowerMessage.includes('room') || lowerMessage.includes('suite') ||
        lowerMessage.includes('reserva') || lowerMessage.includes('disponibilidad')) {
        return '🛏️ **Tipos de Habitaciones:**\n\n**1. Habitación Estándar** (2 personas)\n   • Desde 89€/noche\n   • Cama doble o dos individuales\n   • Baño privado, TV, minibar\n\n**2. Habitación Superior** (2-3 personas)\n   • Desde 129€/noche\n   • Vista al mar, balcón\n   • Desayuno incluido\n\n**3. Suite Familiar** (4 personas)\n   • Desde 189€/noche\n   • Salón independiente\n   • Desayuno incluido\n\n**Cancelación gratuita** hasta 48h antes de la llegada.\n\nPara reservar, contacta con recepción o visita nuestra web.';
    }

    // Intención: Recomendaciones locales
    if (lowerMessage.includes('recomendación') || lowerMessage.includes('recomendacion') || 
        lowerMessage.includes('que hacer') || lowerMessage.includes('visitar') ||
        lowerMessage.includes('turismo') || lowerMessage.includes('actividades') ||
        lowerMessage.includes('tarde') || lowerMessage.includes('plan')) {
        return '🌴 **Recomendaciones Locales:**\n\n**Lugares Turísticos:**\n• **Casco Antiguo** (10 min) - Calles empedradas y arquitectura histórica\n• **Mirador del Faro** (15 min) - Vistas espectaculares al atardecer\n• **Playa de las Rocas** (5 min caminando) - Aguas cristalinas\n\n**Restaurantes Recomendados:**\n• **La Marisquería del Puerto** - Pescado fresco y paellas\n• **El Rincón Mediterráneo** - Cocina tradicional\n• **Taberna del Mar** - Tapas y ambiente local\n\n**Actividades:**\n• Excursiones en barco (salidas diarias 10:00h)\n• Ruta de senderismo costera (3h)\n• Mercadillo local (sábados por la mañana)';
    }

    if (lowerMessage.includes('recomendación') || lowerMessage.includes('recomendacion') || 
        lowerMessage.includes('que hacer') || lowerMessage.includes('qué hacer') ||
        lowerMessage.includes('hacer cerca') || lowerMessage.includes('visitar') ||
        lowerMessage.includes('turismo') || lowerMessage.includes('actividades') ||
        lowerMessage.includes('tarde') || lowerMessage.includes('plan') ||
        lowerMessage.includes('cerca del hotel') || lowerMessage.includes('alrededores') ||
        lowerMessage.includes('cerca del hotel') || lowerMessage.includes('alrededores') ||
        lowerMessage.includes('¿Qué puedo hacer cerca del hotel?') || lowerMessage.includes('sitios')) {
        return '🌴 **Recomendaciones Locales:**\n\n**Lugares Turísticos:**\n• **Casco Antiguo** (10 min) - Calles empedradas y arquitectura histórica\n• **Mirador del Faro** (15 min) - Vistas espectaculares al atardecer\n• **Playa de las Rocas** (5 min caminando) - Aguas cristalinas\n\n**Restaurantes Recomendados:**\n• **La Marisquería del Puerto** - Pescado fresco y paellas\n• **El Rincón Mediterráneo** - Cocina tradicional\n• **Taberna del Mar** - Tapas y ambiente local\n\n**Actividades:**\n• Excursiones en barco (salidas diarias 10:00h)\n• Ruta de senderismo costera (3h)\n• Mercadillo local (sábados por la mañana)';
    }

    // Si no reconoce la intención, usar API de Claude
    return await getChatbotResponseFromAPI(message);
}

// ========================================
// FUNCIONES DE MANEJO DE EVENTOS
// ========================================

/**
 * Envía el mensaje del usuario y obtiene la respuesta del bot
 */
async function sendMessage() {
    if (isProcessing) return;

    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;

    // Deshabilitar controles y marcar como procesando
    isProcessing = true;
    setControlsDisabled(true);

    // Añadir mensaje del usuario
    addMessage('user', message);
    input.value = '';

    // Mostrar indicador de escritura
    showTyping(true);

    // Procesar respuesta
    try {
        const response = await analyzeIntent(message);
        
        setTimeout(() => {
            showTyping(false);
            addMessage('bot', response);
            saveToGoogleSheets(message, response);
            
            // Habilitar controles
            isProcessing = false;
            setControlsDisabled(false);
        }, 1000);
    } catch (error) {
        console.error('Error al procesar mensaje:', error);
        showTyping(false);
        addMessage('bot', '❌ Lo siento, ha ocurrido un error. Por favor, intenta de nuevo o contacta con recepción.');
        isProcessing = false;
        setControlsDisabled(false);
    }
}

/**
 * Maneja los clicks en los botones de acción rápida
 * @param {string} action - Tipo de acción (servicios, habitaciones, recomendaciones, recepcion)
 */
async function handleQuickAction(action) {
    if (isProcessing) return;

    let message = '';
    switch(action) {
        case 'servicios':
            message = 'Quiero saber sobre los servicios del hotel';
            break;
        case 'habitaciones':
            message = 'Información sobre habitaciones';
            break;
        case 'recomendaciones':
            message = 'que recomendaciones me ofreces?';
            break;
        case 'recepcion':
            message = 'Quiero hablar con recepción';
            break;
    }

    document.getElementById('chatInput').value = message;
    sendMessage();
}

/**
 * Maneja el evento de presionar tecla en el input
 * @param {Event} event - Evento del teclado
 */
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage();
    }
}

// ========================================
// INICIALIZACIÓN
// ========================================

/**
 * Inicializa el chatbot cuando se carga la página
 */
document.addEventListener('DOMContentLoaded', function() {
    // Ocultar el indicador de escritura al inicio
    showTyping(false);
    
    // Enfocar el input
    document.getElementById('chatInput').focus();
    
    console.log('Chatbot inicializado con Session ID:', sessionId);
});