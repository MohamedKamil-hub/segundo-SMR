# Historial del Chatbot – Práctica

Este proyecto guarda el historial de chat del bot en Google Sheets.

Cada vez que envías un mensaje al bot, si se procesa correctamente, se guarda en la hoja:

* Fecha y hora
* ID de sesión
* Mensaje del usuario
* Respuesta del bot

**Solo guarda solicitudes exitosas.**

Hoja de cálculo donde se guarda todo:  
[Historial de mensajes](https://docs.google.com/spreadsheets/d/1P7u3G0h96-fpDZW2XaErkujK8Gms-2wms1QBCqZwl50/edit?gid=0#gid=0)

### Cómo usarlo

El `.zip`  descargado contiene:  
* `css/styles.css`  
* `js/chatbot.js`  
* `google-app-script/` con el código que guarda en Google Sheets  
* `index.html`  

Pasos:  
1. Descarga el `.zip`, descomprímelo, copia el path completo de `index.html` y pégalo en tu navegador.  
2. Escribe un mensaje y pulsa **Enter** o el botón de enviar.  
3. El mensaje se mostrará en el chat y se guardará automáticamente en la hoja de cálculo.
